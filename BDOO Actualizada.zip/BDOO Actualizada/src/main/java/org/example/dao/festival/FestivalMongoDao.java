package org.example.dao.festival;

public class FestivalMongoDao {
}
