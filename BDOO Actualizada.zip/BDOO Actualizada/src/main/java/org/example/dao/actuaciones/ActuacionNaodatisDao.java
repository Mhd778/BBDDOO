package org.example.dao.actuaciones;

import org.example.connection.ConexionNeodatis;
import org.example.dao.actuaciones.ActuacionDao;
import org.example.model.Actuacion;
import org.neodatis.odb.ODB;
import org.neodatis.odb.Objects;
import org.neodatis.odb.core.query.IQuery;
import org.neodatis.odb.core.query.criteria.Where;
import org.neodatis.odb.impl.core.query.criteria.CriteriaQuery;

import java.util.ArrayList;
import java.util.List;

public class ActuacionNaodatisDao implements ActuacionDao {


    @Override
    public Actuacion consultar(int id) {

        ODB odb = ConexionNeodatis.obtenerConexion();
        IQuery query = new CriteriaQuery(Actuacion.class, Where.equal("Id",id));
        Objects<Actuacion> objects = odb.getObjects(query);
        Actuacion obj= null;
        if (objects.size()>0){
            obj = objects.getFirst();
        }

        return obj;
    }

    @Override
    public int insertar(Actuacion objeto) throws Exception {
        ODB odb = ConexionNeodatis.obtenerConexion();


        IQuery query = new CriteriaQuery(Actuacion.class, Where.equal("Id", objeto.getId()));
        Objects<Actuacion> objects = odb.getObjects(Actuacion.class);
        if(objects.size()>0){
            throw new Exception(("Id Actuacion dublicado"));
        }

        odb.store(objeto);
        return objeto.getId();
    }

    @Override
    public void eliminar(int id) {

        ODB odb = ConexionNeodatis.obtenerConexion();
        IQuery query  = new CriteriaQuery(Actuacion.class, Where.equal("Id", id));
        Objects<Actuacion> objects = odb.getObjects(query);
        Actuacion obj = null;
        if (objects.size()>0){
            odb.delete(obj);
        }

    }

    @Override
    public void actualizar(Actuacion objeto) {

        ODB odb = ConexionNeodatis.obtenerConexion();

        IQuery query = new CriteriaQuery(Actuacion.class, Where.equal("Id", objeto.getId()));
        Objects<Actuacion> objects = odb.getObjects(query);
        Actuacion objDB = null;

        if (objects.size()> 0){
            objects.getFirst();
        }
        objDB.setNombre(objeto.getNombre());
        objDB.setDescripcion(objeto.getDescripcion());

    }
    @Override
    public List<Actuacion> listar(){


        ODB odb = ConexionNeodatis.obtenerConexion();

        List<Actuacion> lista = new ArrayList<>();
        Objects<Actuacion> obj = odb.getObjects(Actuacion.class);

        while(obj.hasNext()){
            lista.add(obj.next());
        }
        return lista;
    }
}
