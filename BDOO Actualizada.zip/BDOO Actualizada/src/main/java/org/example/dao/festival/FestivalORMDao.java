package org.example.dao.festival;

import org.example.connection.ConexionORM;

import org.example.model.Festival;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class FestivalORMDao  implements FestivalDao{


    public List<Festival> listar(){

        Session conexion = ConexionORM.obtenerConexion().getCurrentSession();
        Transaction transaccion = conexion.beginTransaction();
        List<Festival> lista = conexion.createQuery("from Festival", Festival.class).getResultList();
        transaccion.commit();

        return  lista;
    }


    @Override
    public Festival consultar(int id) {


        Session conexion = ConexionORM.obtenerConexion().getCurrentSession();
        Transaction transaccion = conexion.beginTransaction();
        Festival obj = conexion.get(Festival.class, id);

        transaccion.commit();

        return obj;
    }

    @Override
    public int insertar(Festival objeto) {

        Session conexion = ConexionORM.obtenerConexion().getCurrentSession();
        Transaction transaccion = conexion.beginTransaction();

        conexion.save(objeto);
        transaccion.commit();

        return objeto.getId();
    }

    @Override
    public void eliminar(int id) {


        Session conexion = ConexionORM.obtenerConexion().getCurrentSession();
        Transaction transaccion = conexion.beginTransaction();

        Festival obj = conexion.load(Festival.class, id);
        conexion.delete(obj);

        transaccion.commit();

    }

    @Override
    public void actualizar(Festival objeto) {


        Session conexion = ConexionORM.obtenerConexion().getCurrentSession();
        Transaction transaccion = conexion.beginTransaction();
        Festival objBD = conexion.load(Festival.class, objeto.getId());

        objBD.setNombre(objeto.getNombre());
        objBD.setDescripcion(objeto.getDescripcion());
        objBD.setAforo(objeto.getAforo());
        objBD.setPrecio(objeto.getPrecio());
        objBD.setVenta(objeto.getVenta());
        objBD.setFin(objeto.getFin());
        conexion.update(objBD);
        transaccion.commit();

    }
}
