package org.example.dao.actuaciones;

import org.example.model.Actuacion;

import java.util.List;

public interface ActuacionDao {

 public  Actuacion consultar(int id);
 public  int insertar(Actuacion objeto) throws Exception;
 public void eliminar(int id);
 public void actualizar( Actuacion objeto);

 List<Actuacion> listar();
}
