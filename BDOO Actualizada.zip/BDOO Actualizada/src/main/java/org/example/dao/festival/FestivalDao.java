package org.example.dao.festival;

import org.example.model.Festival;

import java.util.List;

public interface FestivalDao {


        public Festival consultar(int id);
        public  int insertar(Festival objeto) throws Exception;
        public void eliminar(int id);
        public void actualizar(Festival objeto);
        List<Festival> listar();

}
