package org.example.dao.actuaciones;
import com.mongodb.client.model.Filters;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.example.connection.ConexionMongoDB;
import org.example.dao.actuaciones.ActuacionDao;
import org.example.model.Actuacion;
import static com.mongodb.client.model.Filters.*;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;

public class ActuacionmMongoDao implements ActuacionDao {


    private static final String COLECCION = "Actuacion";


    private Document ActuacionADoc(Actuacion objActuacion){

        Document objDoc = null;

        if (objActuacion  != null){

            objDoc = new Document();
            objDoc.put("Id", objActuacion.getId());
            objDoc.put("Nombre", objActuacion.getNombre());
            objDoc.put("Descripcion", objActuacion.getDescripcion());
            objDoc.put("Grupo", objActuacion.getGrupo());
            objDoc.put("Escenario", objActuacion.getEscenario());
            objDoc.put("Inicio", objActuacion.getInicio());
            objDoc.put("Fin", objActuacion.getFin());
        }
        return objDoc;

    }

    private Actuacion docActuacion(Document objDoc){

        Actuacion objActuacion=null;

        if (objDoc != null){
            objActuacion = new Actuacion();
            if (objDoc.getInteger("Id") != null){
                objActuacion.setId(objDoc.getInteger("Id"));
            }
            objActuacion.setNombre(objDoc.getString("Nombre"));
            objActuacion.setDescripcion(objDoc.getString("Descripcion"));
            objActuacion.setGrupo(objDoc.getString("Grupo"));
            objActuacion.setEscenario(objDoc.getString("Escenario"));
            objActuacion.setInicio(objDoc.getInteger("Inicio"));
            objActuacion.setFin(objDoc.getInteger("Fin"));
        }
        return objActuacion;
    }



    @Override
    public List<Actuacion> listar() {

        List<Actuacion> resultado = new ArrayList<>();
        MongoDatabase conexion = ConexionMongoDB.obtenerConexion();
        MongoCollection<Document> mongoCollection = conexion.getCollection(COLECCION);
        List<Document>consulta = mongoCollection.find().into(new ArrayList<Document>());
        Actuacion actuacion = new Actuacion();

        for(int i=0; i<consulta.size(); i++){
            actuacion = docActuacion(consulta.get(i));
            resultado.add(actuacion);
        }

        return resultado;
    }



    @Override
    public Actuacion consultar(int id) {

        MongoDatabase conexion = ConexionMongoDB.obtenerConexion();
        MongoCollection<Document>mongoCollection = conexion.getCollection(COLECCION);
        Document documento = mongoCollection.find(eq("Id",id)).first();

      return docActuacion(documento);
    }


    public int insertar(Actuacion objeto){

        MongoDatabase conexion = ConexionMongoDB.obtenerConexion();
        MongoCollection<Document> mongoColecion = conexion.getCollection(COLECCION);
        Document documento = ActuacionADoc(objeto);
        try{
            mongoColecion.insertOne(documento);
            return objeto.getId();
        }catch (Exception e){
            e.printStackTrace();
        }
        return 0;

    }

    @Override
    public void eliminar(int id) {

        MongoDatabase conexion = ConexionMongoDB.obtenerConexion();
        MongoCollection<Document> mongoCollection = conexion.getCollection(COLECCION);

        try{
            mongoCollection.deleteOne(Filters.eq("Id", id ));
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    public void actualizar(Actuacion objeto) {

        MongoDatabase conexion = ConexionMongoDB.obtenerConexion();
        MongoCollection<Document> mongoCollection = conexion.getCollection(COLECCION);
        Document documento = ActuacionADoc(objeto);

        try{
            mongoCollection.replaceOne(Filters.eq("Id", objeto.getId()),documento);
        }catch (Exception e){
            e.printStackTrace();
        }



    }



}
