package org.example.dao.actuaciones;

import org.example.connection.ConexionORM;
import org.example.model.Actuacion;
import org.hibernate.Session;

import org.hibernate.Transaction;
import java.util.List;

public class ActuacioORMDao implements ActuacionDao {


    @Override
        public List<Actuacion>listar(){

                    Session conexion = ConexionORM.obtenerConexion().getCurrentSession();
                    Transaction transaccion = conexion.beginTransaction();
                    List<Actuacion> lista = conexion.createQuery("from Actuacion", Actuacion.class).getResultList();
                    transaccion.commit();

                    return  lista;
        }

        @Override
        public Actuacion consultar(int id){

            Session conexion = ConexionORM.obtenerConexion().getCurrentSession();
            Transaction transaccion = conexion.beginTransaction();
            Actuacion obj = conexion.get(Actuacion.class, id);

            transaccion.commit();

            return obj;

        }

        @Override
        public  void actualizar(Actuacion objeto){

            Session conexion = ConexionORM.obtenerConexion().getCurrentSession();
            Transaction transaccion = conexion.beginTransaction();
            Actuacion objBD = conexion.load(Actuacion.class, objeto.getId());

            objBD.setNombre(objeto.getNombre());
            objBD.setDescripcion(objeto.getDescripcion());
            objBD.setEscenario(objeto.getEscenario());
            objBD.setGrupo(objeto.getGrupo());
            objBD.setInicio(objeto.getInicio());
            objBD.setFin(objeto.getFin());
            conexion.update(objBD);
            transaccion.commit();

        }

        @Override
        public int insertar(Actuacion objeto){

            Session conexion = ConexionORM.obtenerConexion().getCurrentSession();
            Transaction transaccion = conexion.beginTransaction();

            conexion.save(objeto);
            transaccion.commit();

            return objeto.getId();

        }

        @Override
         public void eliminar(int id) {

            Session conexion = ConexionORM.obtenerConexion().getCurrentSession();
            Transaction transaccion = conexion.beginTransaction();

            Actuacion obj = conexion.load(Actuacion.class, id);
            conexion.delete(obj);

            transaccion.commit();



    }





}
