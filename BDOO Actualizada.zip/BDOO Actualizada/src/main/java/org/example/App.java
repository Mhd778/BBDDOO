package org.example;

import com.mongodb.client.MongoDatabase;
import org.example.connection.ConexionNeodatis;
import org.example.dao.*;
import org.example.model.Actuacion;
import org.example.model.Festival;
import org.neodatis.odb.ODB;
import org.neodatis.odb.core.query.IQuery;


public class App 
{
    public static void main( String[] args )
    {


    }
}
