package org.example.Festival;

public class FestivalDaoMongoTest {
}
