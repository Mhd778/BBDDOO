package org.example.Festival;


import org.example.dao.festival.FestivalDao;
import org.example.dao.festival.FestivalORMDao;
import org.example.model.Festival;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import static org.junit.Assert.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class FestivalORMTest {

    FestivalDao festivalDao = new FestivalORMDao();

    private static int idInsertado;

    @Test
    public void t01Insertar(){

        try {
            String fecha = "18/03/2022";
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            Date parsedDate = dateFormat.parse(fecha);
            Timestamp insertarFecha = new Timestamp(parsedDate.getTime());

            Festival objeto = new Festival();
            objeto.setId(1);
            objeto.setNombre("Fito&Fitipaldis");
            objeto.setDescripcion("Coliseum");
            objeto.setAforo(3000);
            objeto.setPrecio(50);
            objeto.setInicio(18/03/2022);
            objeto.setFin(19/03/2022);
            idInsertado = festivalDao.insertar(objeto);
            assertTrue(idInsertado>0);


            objeto.setId(2);
            objeto.setNombre("Pablo Alboran");
            objeto.setDescripcion("Placio de Opera ");
            objeto.setAforo(2000);
            objeto.setPrecio(50);
            objeto.setInicio(02/05/2022);
            objeto.setFin(04/05/2022);
            idInsertado = festivalDao.insertar(objeto);
            assertTrue(idInsertado>0);

            objeto.setId(3);
            objeto.setNombre("Alejandro Sainz");
            objeto.setDescripcion("Coliseum ");
            objeto.setAforo(3000);
            objeto.setPrecio(50);
            objeto.setInicio(23/06/2022);
            objeto.setFin(24/06/2022);
            idInsertado = festivalDao.insertar(objeto);
            assertTrue(idInsertado>0);



        }catch (Exception e){
            e.printStackTrace();
            assertTrue(false);
        }
    }
 @Test
    public void t02Consultar() {

        try {
            Festival objeto = festivalDao.consultar(idInsertado);
            System.out.println(objeto.toString());
            assertEquals("Pablo Alboran", objeto.getNombre());
        }catch (Exception e){
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void t03Listar() {

        try {
            List<Festival> lista = festivalDao.listar();
            assertTrue(lista.size() > 0);
        }catch(Exception e){
            e.printStackTrace();
            assertTrue(false);

        }
    }

    @Test
    public void t04Actualizar(){

        try{
            Festival objeto = festivalDao.consultar(idInsertado);
            objeto.setNombre("Alejandro Sanz");
            festivalDao.actualizar(objeto);
            Festival objetoActualizado = festivalDao.consultar(idInsertado);
            assertEquals("Alejandro Sanz", objetoActualizado.getNombre());

        }catch (Exception e){
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void t05Eliminar(){

        try{

            festivalDao.eliminar(idInsertado);
            Festival objeto = festivalDao.consultar(idInsertado);
            assertNull(objeto);
        }catch (Exception e ){
            e.printStackTrace();
            assertTrue(false);
        }
    }




}
