package org.example.Actuacion;


import org.example.connection.ConexionMongoDB;
import org.example.dao.actuaciones.ActuacionDao;
import org.example.dao.actuaciones.ActuacionmMongoDao;
import org.example.model.Actuacion;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ActuacionDaoMondoTest {



            ActuacionDao actuacionDao = new ActuacionmMongoDao();

            private static int idInsertado;



    @Test
            public void t01Insertar(){

                try{

                    String fecha= "02/03/2022 ";
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy ");
                    Date parsedDate = dateFormat.parse(fecha);
                    Timestamp insertarFecha = new Timestamp(parsedDate.getTime());

                    Actuacion objeto = new Actuacion();
                    objeto.setId(100);
                    objeto.setNombre("Picasso");
                    objeto.setDescripcion("Guernica");
                    objeto.setGrupo("");
                    objeto.setEscenario("Museo del Prado");
                    objeto.setInicio(04/05/2022);
                    objeto.setFin(07/05/2022);
                    idInsertado = actuacionDao.insertar(objeto);
                    assertTrue(idInsertado>0);



                    fecha= "04/06/2022 ";
                    objeto.setId(2);
                    objeto.setNombre("Dali");
                    objeto.setDescripcion("La persistencia de la memoria");
                    objeto.setGrupo("");
                    objeto.setEscenario("Museo del Prado");
                    objeto.setInicio(04/06/2022);
                    objeto.setFin(07/06/2022);
                    idInsertado = actuacionDao.insertar(objeto);
                    assertTrue(idInsertado>0);

                    fecha= "04/06/2022 ";
                    objeto.setId(3);
                    objeto.setNombre("Pablo Picasso");
                    objeto.setDescripcion("La Mujer que llora");
                    objeto.setGrupo("");
                    objeto.setEscenario("Museo del Prado");
                    objeto.setInicio(04/05/2022);
                    objeto.setFin(07/05/2022);
                    idInsertado = actuacionDao.insertar(objeto);
                    assertTrue(idInsertado>0);

                    fecha= "15/11/2022 ";
                    objeto.setId(4);
                    objeto.setNombre("Frida Kahlo");
                    objeto.setDescripcion("Las dos Fridas");
                    objeto.setGrupo("");
                    objeto.setEscenario("Museo del Prado");
                    objeto.setInicio(15/11/2022);
                    objeto.setFin(20/11/2022);
                    idInsertado = actuacionDao.insertar(objeto);
                    assertTrue(idInsertado>0);



                }catch (Exception e){
                    e.printStackTrace();
                }


            }

           @Test
            public void t02Consultar(){

            Actuacion objeto = actuacionDao.consultar(idInsertado);
               assertEquals("Las dos Fridas", objeto.getDescripcion());
           }

           @Test
            public void t03Listar(){

               List<Actuacion> lista = actuacionDao.listar();
               assertTrue(lista.size()>0);
            }


            @Test
            public void t04ActualizarNombre(){

             Actuacion objeto = actuacionDao.consultar(idInsertado);
                objeto.setNombre("Pablo Picasso");
            actuacionDao.actualizar(objeto);

            Actuacion objetoActualizado = actuacionDao.consultar(idInsertado);
            assertEquals("Pablo Picasso", objetoActualizado.getNombre());

            }

            @Test
            public void t05Eliminar(){

            actuacionDao.eliminar(idInsertado);
            Actuacion objeto = actuacionDao.consultar(idInsertado);
            assertNull(objeto);

            }

            @Test
            public void t09CerrarConexion(){

                ConexionMongoDB.cerrarConexion();
                assertTrue(true);

            }




}
