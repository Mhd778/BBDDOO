package org.example.model;

public class Festival {
    private  int Id;
    private String Nombre;
    private String Descripcion;
    private int Inicio;
    private int Fin;
    private  int Aforo;
    private int Precio;
    private int Venta;

    public Festival() {
    }

    public Festival(int id, String nombre, String descripcion, int inicio, int fin, int aforo, int precio, int venta) {
        Id = id;
        Nombre = nombre;
        Descripcion = descripcion;
        Inicio = inicio;
        Fin = fin;
        Aforo = aforo;
        Precio = precio;
        Venta = venta;

    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public int getInicio() {
        return Inicio;
    }

    public void setInicio(int inicio) {
        Inicio = inicio;
    }

    public int getFin() {
        return Fin;
    }

    public void setFin(int fin) {
        Fin = fin;
    }

    public int getAforo() {
        return Aforo;
    }

    public void setAforo(int aforo) {
        Aforo = aforo;
    }

    public int getPrecio() {
        return Precio;
    }

    public void setPrecio(int precio) {
        Precio = precio;
    }

    public int getVenta() {
        return Venta;
    }

    public void setVenta(int venta) {
        Venta = venta;
    }

    @Override
    public String toString() {
        return "Festival{" +
                "Id=" + Id +
                ", Nombre='" + Nombre + '\'' +
                ", Descripcion='" + Descripcion + '\'' +
                ", Inicio=" + Inicio +
                ", Fin=" + Fin +
                ", Aforo=" + Aforo +
                ", Precio=" + Precio +
                ", Venta=" + Venta +
                '}';
    }
}
