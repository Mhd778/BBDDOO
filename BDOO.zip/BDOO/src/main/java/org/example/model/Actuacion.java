package org.example.model;

public class Actuacion {

    private  int Id;
    private int IdFestival;
    private String Nombre;
    private String Descripcion;
    private String Grupo;
    private String Escenario;
    private int Inicio;
    private int Fin;

    public Actuacion() {
    }

    public Actuacion(int id, int idFestival, String nombre, String descripcion, String grupo, String escenario, int inicio, int fin) {
        Id = id;
        IdFestival = idFestival;
        Nombre = nombre;
        Descripcion = descripcion;
        Grupo = grupo;
        Escenario = escenario;
        Inicio = inicio;
        Fin = fin;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public int getIdFestival() {
        return IdFestival;
    }

    public void setIdFestival(int idFestival) {
        IdFestival = idFestival;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getGrupo() {
        return Grupo;
    }

    public void setGrupo(String grupo) {
        Grupo = grupo;
    }

    public String getEscenario() {
        return Escenario;
    }

    public void setEscenario(String escenario) {
        Escenario = escenario;
    }

    public int getInicio() {
        return Inicio;
    }

    public void setInicio(int inicio) {
        Inicio = inicio;
    }

    public int getFin() {
        return Fin;
    }

    public void setFin(int fin) {
        Fin = fin;
    }

    @Override
    public String toString() {
        return "Actuacion{" +
                "Id=" + Id +
                ", IdFestival=" + IdFestival +
                ", Nombre='" + Nombre + '\'' +
                ", Descripcion='" + Descripcion + '\'' +
                ", Grupo='" + Grupo + '\'' +
                ", Escenario='" + Escenario + '\'' +
                ", Inicio=" + Inicio +
                ", Fin=" + Fin +
                '}';
    }
}
