package org.example.dao;

import org.example.connection.ConexionNeodatis;
import org.example.model.Actuacion;
import org.neodatis.odb.ODB;
import org.neodatis.odb.Objects;

import java.util.ArrayList;
import java.util.List;

public class ActuacionDB implements ActuacionDao {

public List<Actuacion> listar(){

    ODB odb = ConexionNeodatis.obtenerConexion();

    List<Actuacion> lista = new ArrayList<>();
    Objects<Actuacion> objetos = odb.getObjects(Actuacion.class);
    while (objetos.hasNext());{
    lista.add(objetos.next());}
    return lista;
}

public Actuacion

}
