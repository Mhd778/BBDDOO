package org.example.dao;

public class FestivalDB {
}
