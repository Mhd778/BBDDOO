package org.example.dao;

public interface FestivalDao {
}
